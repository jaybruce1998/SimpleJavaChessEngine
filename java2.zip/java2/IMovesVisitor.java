public interface IMovesVisitor {
    boolean Done();

    void Consider(Move move);

    void Consider(int from, int to);

    void Consider(int from, int to, Piece promotion);

    void AddUnchecked(Move move);
}
