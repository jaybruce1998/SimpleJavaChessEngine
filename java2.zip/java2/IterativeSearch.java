import java.util.function.Supplier;

public class IterativeSearch {
    private int Depth;

    public int getDepth() {
        return Depth;
    }

    private long EvalCount;
    private int Score;

    public int getScore() {
        return Score;
    }

    public Board Position() {
        return new Board(_root); //return copy, _root must not be modified during search!
    }

    public Move[] PrincipalVariation() {
        return Depth > 0 ? _pv.GetLine(Depth) : null;
    }

    public boolean Aborted() {
        return _killSwitch.Triggered();
    }

    public boolean GameOver() {
        return Score == Evaluation.MinValue || Score == Evaluation.MaxValue;
    }

    private final Board _root;
    private final LegalMoves _rootMoves;
    private final PrincipalVariation _pv;
    private KillSwitch _killSwitch;

    public IterativeSearch(Board board) {
        _root = new Board(board);
        _rootMoves = new LegalMoves(board);
        _pv = new PrincipalVariation(20);
    }

    public void Search(int maxDepth) {
        while (maxDepth > Depth)
            searchDeeper();
    }

    public void searchDeeper() {
        SearchDeeper(null);
    }

    public void SearchDeeper(Supplier<Boolean> killSwitch) {
        _pv.Grow(++Depth);
        if (GameOver())
            return;

        _killSwitch = new KillSwitch(killSwitch);
        SearchWindow window = SearchWindow.infinite();//IF YOU DO THIS WITH STRUCTS IT MAKES A COPY!!! so we were modifying the original Infinite before here, FUCK!
        Score = EvalPosition(_root, Depth, window);
    }

    private int EvalMove(Board position, Move move, int depth, SearchWindow window) {
        Board resultingPosition = new Board(position, move);
        return EvalPosition(resultingPosition, depth - 1, window);
    }

    private int EvalPosition(Board position, int depth, SearchWindow window) {
        if (depth == 0) {
            EvalCount++;
            return Evaluation.Evaluate(position);
        }

        if (_killSwitch.Triggered())
            return 0;

        Color color = position.ActiveColor();
        LegalMoves moves = (depth == Depth) ? _rootMoves : new LegalMoves(position);//used at each search depth since we have to "start over" from the original position each time

        //having no legal moves can mean two things: (1) lost or (2) draw?
        if (moves.isEmpty()) {
            _pv.Clear(depth);
            return position.IsChecked(position.ActiveColor()) ? color.value * Evaluation.MinValue : 0;
        }

        Move killer = _pv.get(depth);
        if (moves.contains(killer))//refactor?
        {
            int score = EvalMove(position, killer, depth, new SearchWindow(window));//yeah genuinely
            if (window.Inside(score, color)) {
                //this is a new best score!
                _pv.set(depth, killer);
                if (window.Cut(score, color))
                    return window.GetScore(color);
            }
        }

        for (Move move : moves) {
            if (killer != null && move.equals(killer))
                continue;

            int score = EvalMove(position, move, depth, new SearchWindow(window));//FUCK C# AND FUCK STRUCTS! even AI can't deal with this copying values BULLSHIT
            if (window.Inside(score, color)) {
                //this is a new best score!
                _pv.set(depth, move);
                if (window.Cut(score, color))
                    return window.GetScore(color);
            }
        }

        return window.GetScore(color);
    }
}