public class Move {
    public final byte FromIndex;
    public final byte ToIndex;
    public final Piece Promotion;

    public Move(int fromIndex, int toIndex) {
        FromIndex = (byte) fromIndex;
        ToIndex = (byte) toIndex;
        Promotion = Piece.None;
    }

    public Move(int fromIndex, int toIndex, Piece promotion) {
        FromIndex = (byte) fromIndex;
        ToIndex = (byte) toIndex;
        Promotion = promotion;
    }

    public Move(String uciMoveNotation) {
        if (uciMoveNotation.length() < 4)
            throw new IllegalArgumentException("Long algebraic notation expected. '{uciMoveNotation}' is too short!");
        if (uciMoveNotation.length() > 5)
            throw new IllegalArgumentException("Long algebraic notation expected. '{uciMoveNotation}' is too long!");

        String fromSquare = uciMoveNotation.substring(0, 2);
        String toSquare = uciMoveNotation.substring(2, 4);
        FromIndex = Notation.ToSquareIndex(fromSquare);
        ToIndex = Notation.ToSquareIndex(toSquare);
        //the presence of a 5th character should mean promotion
        Promotion = (uciMoveNotation.length() == 5) ? Notation.ToPiece(uciMoveNotation.charAt(4)) : Piece.None;
    }

    public boolean equals(Object obj) {
        if (obj instanceof Move move)
            return this.equals(move);

        return false;
    }

    public boolean equals(Move other) {
        return (FromIndex == other.FromIndex) && (ToIndex == other.ToIndex) && (Promotion == other.Promotion);
    }

    @Override
    public int hashCode() {
        //int is big enough to represent move fully. maybe use that for optimization at some point
        return FromIndex + (ToIndex << 8) + (Promotion.value << 16);
    }

    @Override
    public String toString() {
        //result represents the move in the long algebraic notation (without piece names)
        String result = Notation.ToSquareName(FromIndex);
        result += Notation.ToSquareName(ToIndex);
        //the presence of a 5th character should mean promotion
        if (Promotion != Piece.None)
            result += Notation.ToChar(Promotion);

        return result;
    }

    public static Move BlackCastlingShort = new Move("e8g8");
    public static Move BlackCastlingLong = new Move("e8c8");
    public static Move WhiteCastlingShort = new Move("e1g1");
    public static Move WhiteCastlingLong = new Move("e1c1");

    public static Move BlackCastlingShortRook = new Move("h8f8");
    public static Move BlackCastlingLongRook = new Move("a8d8");
    public static Move WhiteCastlingShortRook = new Move("h1f1");
    public static Move WhiteCastlingLongRook = new Move("a1d1");

    public static void main(String[] a) {
        Move m1 = new Move("e2e4");
        Move m2 = new Move("e2e4");
        Move m3 = new Move("e7e5");
        Move m4 = new Move("e7e8q"); // promotion

        System.out.println(m1.equals(m2));      // true
        System.out.println(m1.equals(m3));     // false
        System.out.println(m3.equals(m4));     // false
        System.out.println(m1.hashCode() == m2.hashCode()); // should match
    }
}

