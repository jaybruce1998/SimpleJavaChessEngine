public enum Piece {
    None(0),
    WhitePawn(1),
    WhiteKnight(2),
    WhiteBishop(3),
    WhiteRook(4),
    WhiteQueen(5),
    WhiteKing(6),
    BlackPawn(7),
    BlackKnight(8),
    BlackBishop(9),
    BlackRook(10),
    BlackQueen(11),
    BlackKing(12);

    public final int value;

    Piece(int value) {
        this.value = value;
    }

    public Piece OfColor(Color color) {
        //if black offset type by 7 (-1 & 7 == 7) otherwise by 1 (1 & 7 == 1)
        return values()[Pieces.GetType(this).value + (color.value & 7)];
    }
}
