public class Pieces {
    public static Color GetColor(Piece piece) {
        if (piece.value >= Piece.BlackPawn.value)
            return Color.Black;
        else if (piece.value >= Piece.WhitePawn.value)
            return Color.White;

        throw new IllegalArgumentException(piece + " has no color!");
    }

    public static PieceType GetType(Piece piece) {
        if (piece.value >= Piece.BlackPawn.value)
            return PieceType.values()[piece.value - 7];
        else if (piece.value >= Piece.WhitePawn.value)
            return PieceType.values()[piece.value - 1];

        throw new IllegalArgumentException(piece + " has no type!");
    }

    public static Color Flip(Color color) {
        return color == Color.White ? Color.Black : Color.White;
    }

    static boolean IsWhite(Piece piece) {
        return piece.value >= Piece.WhitePawn.value && piece.value < Piece.BlackPawn.value;
    }

    static boolean IsBlack(Piece piece) {
        return piece.value >= Piece.BlackPawn.value;
    }

    static Piece Pawn(Color color) {
        return Piece.values()[PieceType.Pawn.value + (color.value & 7)];
    }

    static Piece King(Color color) {
        return Piece.values()[PieceType.King.value + (color.value & 7)];
    }

    static Piece Queen(Color color) {
        return Piece.values()[PieceType.Queen.value + (color.value & 7)];
    }

    static Piece Rook(Color color) {
        return Piece.values()[PieceType.Rook.value + (color.value & 7)];
    }

    static Piece Knight(Color color) {
        return Piece.values()[PieceType.Knight.value + (color.value & 7)];
    }

    static Piece Bishop(Color color) {
        return Piece.values()[PieceType.Bishop.value + (color.value & 7)];
    }
}