import java.util.Scanner;

public class Program {
    public static void main(String[] args) {
        Board board = new Board(Board.STARTING_POS_FEN);
        boolean aiTurn = true;
        Scanner input = new Scanner(System.in);
        while (true) {
            LegalMoves legalMoves = new LegalMoves(board);
            if (aiTurn) {
                System.out.println("AI turn, legal moves: ");
                for (int i = 0; i < legalMoves.size(); i++) {
                    System.out.print(i + 1 + ": " + legalMoves.get(i) + ", ");
                }
                System.out.println();
                IterativeSearch search = new IterativeSearch(board);
                search.Search(3);
                System.out.println("Score " + search.getScore());
                board.Play(search.PrincipalVariation()[0]);
                System.out.println("AI played " + search.PrincipalVariation()[0]);
            } else {
                System.out.println("Your turn, legal moves: ");
                for (int i = 0; i < legalMoves.size(); i++) {
                    System.out.print(i + 1 + ": " + legalMoves.get(i) + ", ");
                }
                System.out.println();
                Move move = null;
                while (move == null) {
                    try {
                        move = new Move(input.nextLine());
                        if (legalMoves.contains(move)) {
                            System.out.println("You played " + move + ".");
                        } else {
                            System.out.println("That's illegal!");
                            move = null;
                        }
                    } catch (Exception e) {
                        System.out.println("Invalid move, try again.");
                        move = null;
                    }
                }
                board.Play(move);
            }
            System.out.println(board);
            aiTurn = !aiTurn;
        }
    }
}