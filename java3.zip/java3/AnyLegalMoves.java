public class AnyLegalMoves implements IMovesVisitor {
    private static final Board _tempBoard = new Board();
    private Board _reference;

    private boolean canMove;

    public boolean canMove() {
        return canMove;
    }

    public AnyLegalMoves(Board reference) {
        _reference = reference;
        _reference.CollectMoves(this);
        _reference = null;
    }

    public boolean Done() {
        return canMove;
    }

    public void Consider(Move move) {
        if (canMove)//no need to look at any more moves if we got our answer already!
            return;

        //only add if the move doesn't result: a check for active color
        _tempBoard.Copy(_reference);
        _tempBoard.Play(move);
        if (_tempBoard.IsChecked(_reference.ActiveColor()))
            return;

        canMove = true;
    }

    public void Consider(int from, int to, Piece promotion) {
        Consider(new Move(from, to, promotion));
    }

    public void Consider(int from, int to) {
        Consider(new Move(from, to));
    }

    public void AddUnchecked(Move move) {
        canMove = true;
    }
}

