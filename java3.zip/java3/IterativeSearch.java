import java.util.List;
import java.util.function.Supplier;

public class IterativeSearch {
    private long PositionsEvaluated;
    private long MovesGenerated;
    private long MovesPlayed;
    private int Depth;

    private int Score;

    public int getScore() {
        return Score;
    }

    public Board Position() {
        return new Board(_root); //return copy, _root must not be modified during search!
    }

    public Move[] PrincipalVariation() {
        return Depth > 0 ? _pv.GetLine(Depth) : null;
    }

    public boolean Aborted() {
        return _killSwitch.Triggered();
    }

    public boolean GameOver() {
        return _pv.IsGameOver(Depth);
    }

    private final Board _root;
    private final List<Move> _rootMoves;
    private final PrincipalVariation _pv;
    private KillSwitch _killSwitch;

    public IterativeSearch(Board board) {
        _root = new Board(board);
        _rootMoves = new LegalMoves(board);
        _pv = new PrincipalVariation(20);
    }

    public IterativeSearch(Board board, List<Move> rootMoves)
    {
        _root = new Board(board);
        _rootMoves = rootMoves;
        _pv = new PrincipalVariation(20);
    }

    public void Search(int maxDepth) {
        while (!GameOver()&&maxDepth > Depth)
            searchDeeper();
    }

    public void searchDeeper() {
        SearchDeeper(null);
    }

    public void SearchDeeper(Supplier<Boolean> killSwitch) {
        if (GameOver())
            return;
        _pv.Grow(++Depth);

        _killSwitch = new KillSwitch(killSwitch);
        SearchWindow window = SearchWindow.infinite();
        Score = EvalPosition(_root, Depth, window);
    }

    private Iterable<MoveBoard> Expand(Board position, int depth)
    {
        MoveSequence moves = (depth == Depth) ? MoveSequence.FromList(position, _rootMoves) : MoveSequence.AllMoves(position);
        MovesGenerated += moves.Count();
        return moves.Boost(_pv.get(depth)).SortCaptures().PlayMoves();
    }

    private Iterable<MoveBoard> Expand(Board position)
    {
        return Expand(position, 0);
    }

    private Iterable<Board> Expand(Board position, boolean escapeCheck)
    {
        MoveSequence nodes = escapeCheck ? MoveSequence.AllMoves(position) : MoveSequence.CapturesOnly(position);
        return nodes.SortCaptures().Play();
    }

    private int EvalPosition(Board position, int depth, SearchWindow window) {

        if (_killSwitch.Triggered())
            return 0;

        if (depth == 0)
            return QEval(position, window);//refactor?

        PositionsEvaluated++;

        Color color = position.ActiveColor();

        int expandedNodes = 0;
        for(MoveBoard mb: Expand(position, depth))
        {
            Move move= mb.move;
            Board child = mb.board;
            expandedNodes++;

            //For all rootmoves after the first search with "null window"
            if (expandedNodes > 1 && depth == Depth)
            {
                SearchWindow nullWindow = window.GetNullWindow(color);
                int nullScore = EvalPosition(child, depth - 1, new SearchWindow(nullWindow));
                if (nullWindow.Outside(nullScore, color))
                    continue;
            }

            int score = EvalPosition(child, depth - 1, new SearchWindow(window));
            if (window.Inside(score, color))
            {
                //this is a new best score!
                _pv.set(depth, move);
                if (window.Cut(score, color))
                    return window.GetScore(color);
            }
        }
        MovesPlayed += expandedNodes;

        if (expandedNodes == 0) //no expansion happened from this node!
        {
            //having no legal moves can mean two things: (1) lost or (2) draw?
            _pv.Clear(depth);
            return position.IsChecked(position.ActiveColor()) ? color.value * PieceSquareTable.LostValue : 0;
        }

        return window.GetScore(color);
    }

    private int QEval(Board position, SearchWindow window)
    {
        PositionsEvaluated++;
        Color color = position.ActiveColor();

        //if inCheck we can't use standPat, need to escape check!
        boolean inCheck = position.IsChecked(color);
        if (!inCheck)
        {
            int standPatScore = PieceSquareTable.Evaluate(position);
            //Cut will raise alpha and perform beta cutoff when standPatScore is too good
            if (window.Cut(standPatScore, color))
                return window.GetScore(color);
        }

        int expandedNodes = 0;
        //play remaining captures (or any moves if king is in check)
        for(Board child: Expand(position, inCheck))
        {
            expandedNodes++;
            //recursively evaluate the resulting position (after the capture) with QEval
            int score = QEval(child, new SearchWindow(window));

            //Cut will raise alpha and perform beta cutoff when the move is too good
            if (window.Cut(score, color))
                break;
        }

        //checkmate?
        if (expandedNodes == 0 && inCheck)
            return color.value * PieceSquareTable.LostValue;

        //stalemate?
        if (expandedNodes == 0 && !AnyLegalMoves(position))
            return 0;

        //can't capture. We return the 'alpha' which may have been raised by "stand pat"
        return window.GetScore(color);
    }

    public boolean AnyLegalMoves(Board position)
    {
        var moves = new AnyLegalMoves(position);
        return moves.canMove();
    }
}