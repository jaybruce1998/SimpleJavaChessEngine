import java.util.ArrayList;

public class LegalMoves extends ArrayList<Move> implements IMovesVisitor {
    private static final Board _tempBoard = new Board();
    private Board _reference;

    public LegalMoves(Board reference) {
        super(40);
        _reference = reference;
        _reference.CollectMoves(this);
        _reference = null;
    }

    public boolean Done() {
        return false;
    }

    public void Consider(Move move) {
        //only add if the move doesn't result in a check for active color
        _tempBoard.Copy(_reference);
        _tempBoard.Play(move);
        if (_tempBoard.IsChecked(_reference.ActiveColor()))
            return;

        add(move);
    }

    public void Consider(int from, int to, Piece promotion) {
        Consider(new Move(from, to, promotion));
    }

    public void Consider(int from, int to) {
        Consider(new Move(from, to));
    }

    public void AddUnchecked(Move move) {
        add(move);
    }
}
