public class MoveBoard
{
	public Move move;
	public Board board;
	public MoveBoard(Move move, Board board)
	{
		this.move = move;
		this.board = board;
	}
}