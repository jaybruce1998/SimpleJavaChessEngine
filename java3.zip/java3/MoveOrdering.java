import java.util.List;

public class MoveOrdering {
    private static int Score(Move move, Board context)
    {
        Piece victim = context.get(move.ToIndex);
        if (victim == Piece.None)
            return 0;//we don't sort those
        Piece attacker = context.get(move.FromIndex);
        //Rating: Victims value first - offset by the attackers value
        return ((100 * victim.value - attacker.value));
    }

    public static void SortMvvLva(List<Move> moves, Board context) {
        moves.sort((a, b) -> Integer.compare(Score(b, context), Score(a, context)));//refactor? should be descending order
    }
}
