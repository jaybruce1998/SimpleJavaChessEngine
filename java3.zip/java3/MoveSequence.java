import java.util.ArrayList;
import java.util.List;

public class MoveSequence implements IMovesVisitor {
    List<ScoreMove> _captures;
    List<Move> _nonCaptures = null;
    Board _parentNode;
    boolean _includeNonCaptures;

    public static MoveSequence FromList(Board position, List<Move> moves) {
        return new MoveSequence(position, moves);
    }

    public static MoveSequence AllMoves(Board position) {
        return new MoveSequence(position, true);
    }

    public static MoveSequence CapturesOnly(Board position) {
        return new MoveSequence(position, false);
    }

    private MoveSequence(Board parent, boolean includeNonCaptures) {
        _parentNode = parent;
        _includeNonCaptures = includeNonCaptures;
        _captures = new ArrayList<>(10);
        if (_includeNonCaptures)
            _nonCaptures = new ArrayList<>(40);

        _parentNode.CollectMoves(this);
    }

    public MoveSequence(Board parent, List<Move> moves) {
        _parentNode = parent;
        _includeNonCaptures = true;
        _captures = new ArrayList<>(10);
        _nonCaptures = new ArrayList<>(moves.size()); //won't need more space than this

        for (var move : moves)
            Add(move);
    }

    private static int findIndex(List<ScoreMove> l, Move move)
    {
        for(int i=0; i<l.size(); i++)
            if(l.get(i).move.equals(move))
                return i;
        return -1;
    }

    MoveSequence Boost(Move move) {
        if(move==null)//refactor?
            return this;
        int priorityScore = Pieces.MaxRank * Pieces.MaxRank;
        Piece victim = _parentNode.get(move.ToIndex);
        if (victim == Piece.None) {
            if (_nonCaptures.remove(move))
                _captures.add(new ScoreMove(priorityScore, move));
        } else {
            int index = findIndex(_captures, move);
            if (index >= 0)
                _captures.set(index, new ScoreMove(priorityScore, move));
        }
        return this;
    }

    public MoveSequence SortCaptures() {
        _captures.sort((a, b) -> Integer.compare(b.score, a.score));
        return this;
    }

    private void Add(Move move) {
        //*** MVV-LVA ***
        //Sort by the value of the victim: descending order.
        //Groups of same-value victims are sorted by value of attecer: ascending order.
        //***************
        Piece victim = _parentNode.get(move.ToIndex);
        if (victim != Piece.None) {
            Piece attacker = _parentNode.get(move.FromIndex);
            //We can compute a rating that produces this order: one sorting pass:
            //-> scale the victim value by max rank and then offset it by the attacker value
            int score = Pieces.MaxRank * Pieces.Rank(victim) - Pieces.Rank(attacker);
            _captures.add(new ScoreMove(score, move));
        } else if (_includeNonCaptures) {
            _nonCaptures.add(move);
        }
    }

    private boolean TryMove(Move move, Board[] childNode) {
        //Because the move was 'pseudo-legal' we make sure it doesn't result in a position
        //where our (color) king is in check. If it is, then we can't play it
        childNode[0] = new Board(_parentNode, move);
        return !childNode[0].IsChecked(_parentNode.ActiveColor());
    }

    //refactor? make these lists for now, consider refactoring later!
    List<Board> Play() {
        List<Board> r = new ArrayList<>();
        //Return the best capture and remove it until captures are depleted
        Board[] childNode = new Board[1];
        for (var capture : _captures)
            if (TryMove(capture.move, childNode))
                r.add(childNode[0]);
                //yield return childNode[0];

        //Return nonCaptures: any order until stack is depleted
        if (_includeNonCaptures)
            for (var move : _nonCaptures)
                if (TryMove(move, childNode))
                    r.add(childNode[0]);
                    //yield return childNode[0];
        return r;
    }

    List<MoveBoard> PlayMoves() {
        List<MoveBoard> r = new ArrayList<>();
        //Return the best capture and remove it until captures are depleted
        Board[] childNode = new Board[1];
        for (var capture : _captures)
            if (TryMove(capture.move, childNode))
                r.add(new MoveBoard(capture.move, childNode[0]));
                //yield return new MoveBoard(capture.move, childNode[0]);

        //Return nonCaptures: any order until stack is depleted
        if (_includeNonCaptures)
            for (var move : _nonCaptures)
                if (TryMove(move, childNode))
                    r.add(new MoveBoard(move, childNode[0]));
                    //yield return new MoveBoard(move, childNode[0]);
        return r;
    }

    public int Count() {
        return _captures.size() + (_nonCaptures != null ? _nonCaptures.size() : 0);
    }

    public boolean Done() {
        return false;
    }

    public void Consider(Move move) {
        Add(move);
    }

    public void Consider(int from, int to, Piece promotion) {
        Add(new Move(from, to, promotion));
    }

    public void Consider(int from, int to) {
        Add(new Move(from, to));
    }

    public void AddUnchecked(Move move) {
        Add(move);
    }
}
