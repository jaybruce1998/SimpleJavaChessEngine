import java.io.BufferedReader;
import java.io.StringReader;

public class PieceSquareTable
{
    public static int LostValue = -9999;

    public static final int[][] Tables;

    public static final String Default = """
    #Source: https://www.chessprogramming.org/Simplified_Evaluation_Function
    #But I rewrote the King's table because I don't support mg/eg distinction

    Pawn 100
     0|  0|  0|  0|  0|  0|  0|  0
    50| 50| 50| 50| 50| 50| 50| 50
    10| 10| 20| 30| 30| 20| 10| 10
     5|  5| 10| 25| 25| 10|  5|  5
     0|  0|  0| 20| 20|  0|  0|  0
     5| -5|-10|  0|  0|-10| -5|  5
     5| 10| 10|-20|-20| 10| 10|  5
     0|  0|  0|  0|  0|  0|  0|  0

    Knight 320
    -50|-40|-30|-30|-30|-30|-40|-50
    -40|-20|  0|  0|  0|  0|-20|-40
    -30|  0| 10| 15| 15| 10|  0|-30
    -30|  5| 15| 20| 20| 15|  5|-30
    -30|  0| 15| 20| 20| 15|  0|-30
    -30|  5| 10| 15| 15| 10|  5|-30
    -40|-20|  0|  5|  5|  0|-20|-40
    -50|-40|-30|-30|-30|-30|-40|-50

    Bishop 330
    -20|-10|-10|-10|-10|-10|-10|-20
    -10|  0|  0|  0|  0|  0|  0|-10
    -10|  0|  5| 10| 10|  5|  0|-10
    -10|  5|  5| 10| 10|  5|  5|-10
    -10|  0| 10| 10| 10| 10|  0|-10
    -10| 10| 10| 10| 10| 10| 10|-10
    -10|  5|  0|  0|  0|  0|  5|-10
    -20|-10|-10|-10|-10|-10|-10|-20

    Rook 500
      0|  0|  0|  0|  0|  0|  0|  0
      5| 10| 10| 10| 10| 10| 10|  5
     -5|  0|  0|  0|  0|  0|  0| -5
     -5|  0|  0|  0|  0|  0|  0| -5
     -5|  0|  0|  0|  0|  0|  0| -5
     -5|  0|  0|  0|  0|  0|  0| -5
     -5|  0|  0|  0|  0|  0|  0| -5
      0|  0|  0|  5|  5|  0|  0|  0

    Queen 900
    -20|-10|-10| -5| -5|-10|-10|-20
    -10|  0|  0|  0|  0|  0|  0|-10
    -10|  0|  5|  5|  5|  5|  0|-10
     -5|  0|  5|  5|  5|  5|  0| -5
      0|  0|  5|  5|  5|  5|  0| -5
    -10|  5|  5|  5|  5|  5|  0|-10
    -10|  0|  5|  0|  0|  0|  0|-10
    -20|-10|-10| -5| -5|-10|-10|-20

    King 66666
    -10| 10|  10| -20| -20|  10| 10| -10
    -20|  0|  20|  20|  20|  20|  0| -20
    -30|  0|   0|  10|   0|   0|  0| -30
    -30|  0|   0|   0|   0|   0|  0| -30
    -30|-10|   0|   0|   0|   0|-10| -30
    -20|-20| -20| -30| -30| -20|-20| -20
      0|  0| -10| -30| -30| -10|  0|   0
     10| 20|  10| -10| -10|   0| 20|  10""";

    static
    {
        //14 = Black * [None..King] + White * [None..King]
        Tables = new int[14][64];
        Load(Default);
    }

    public static void Load(String pst)
    {
        try {
            Load(new BufferedReader(new StringReader(pst)));//apparently more efficient than a Scanner??
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void Load(BufferedReader reader) throws Exception
    {
        String line;
        while ((line=reader.readLine())!=null)
        {
            line = line.trim();
            if (line.isBlank() || line.startsWith("#"))//same as isEmpty() (length()==0) except it ignores white space (although we just trimmed it)...
                continue;
            String[] tokens = line.split(" ");
            if (tokens.length != 2)
                throw new IllegalArgumentException("Exactly 2 tokens 'PieceType Value' expected. '{line}' not valid!");
            String pieceType = tokens[0].toUpperCase();
            int value = Integer.parseInt(tokens[1]);
            switch (pieceType)
            {
                case "PAWN":
                    ParseTable(Piece.Pawn, value, reader); break;
                case "KNIGHT":
                    ParseTable(Piece.Knight, value, reader); break;
                case "BISHOP":
                    ParseTable(Piece.Bishop, value, reader); break;
                case "ROOK":
                    ParseTable(Piece.Rook, value, reader); break;
                case "QUEEN":
                    ParseTable(Piece.Queen, value, reader); break;
                case "KING":
                    ParseTable(Piece.King, value, reader); break;
                default:
                    throw new IllegalArgumentException("PieceType {pieceType} not recognized!");
            }
        }
    }

    private static void ParseTable(Piece piece, int pieceValue, BufferedReader reader) throws Exception
    {
        //read 8 lines for the 8 ranks of the board
        for (int rank = 0; rank < 8; rank++)
        {
            String line = reader.readLine();
            String[] tokens = line.split("\\|");//fuck you regex
            if (tokens.length != 8)
                throw new IllegalArgumentException("Exactly 8 numeral tokens expected. '"+line+"' is not valid!");

            for (int file = 0; file < 8; file++)
            {
                int squareValueOffset = Integer.parseInt(tokens[file].trim());//C# doesn't care about spaces, java does
                int pieceSquareValue = pieceValue + squareValueOffset;
                //square indices in the piece table
                int iBlackSquare = rank * 8 + file;
                int iWhiteSquare = (7 - rank) * 8 + file;
                Tables[PieceTableIndex(Pieces.get(piece.value | Piece.Black.value))][iBlackSquare] = -pieceSquareValue;
                Tables[PieceTableIndex(Pieces.get(piece.value | Piece.White.value))][iWhiteSquare] = (pieceValue + squareValueOffset);
            }
        }
    }

    //strip the first bit and
    private static int PieceTableIndex(Piece piece)
    {
        return (piece.value >> 1);
    }

    public static int Value(Piece piece, int squareIndex)
    {
        return Tables[PieceTableIndex(piece)][squareIndex];
    }

    public static int Evaluate(Board board)
    {
        int score = 0;
        for (int i = 0; i < 64; i++)
            score += Tables[PieceTableIndex(board.get(i))][i];
        return score;
    }

}