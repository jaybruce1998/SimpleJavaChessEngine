import java.util.HashMap;

public class Pieces {
    public static final int MaxRank = 6;

    public static int Rank(Piece piece) {
        return (piece.value >> 2);
    }

    private static final HashMap<Integer, Piece> pieceMap;
    static
    {
        pieceMap=new HashMap<>();
        for(Piece p: Piece.values())
            pieceMap.put(p.value, p);
    }

    public static Piece get(int v)
    {
        return pieceMap.get(v);
    }

    public static Piece Type(Piece piece) {
        return pieceMap.get(piece.value & Piece.TypeMask);
    }

    public static Piece Color(Piece piece) {
        return pieceMap.get(piece.value & Piece.ColorMask);
    }

    //adding 2 maps Color.White (1) to Piece.White (3) and Color.Black (-1) to Piece.Black (1)
    public static Piece Color(Color color) {
        return pieceMap.get(color.value + 2);
    }

    static boolean IsWhite(Piece piece) {
        return Color(piece) == Piece.White;
    }

    static boolean IsBlack(Piece piece) {
        return Color(piece) == Piece.Black;
    }

    public static Color Flip(Color color) {
        return color==Color.Black?Color.White:Color.Black;
    }
}