class PrincipalVariation {
    final Move[] _moves;

    public PrincipalVariation(int maxDepth) {
        int length = Index(maxDepth + 1);
        _moves = new Move[length];
    }

    private int Index(int depth) {
        //return depth + (depth - 1) + (depth - 2) + ... + 1;
        int d = depth - 1;
        return (d * d + d) / 2;
    }

    public void Clear(int depth) {
        int iDepth = Index(depth);

        for (int i = 0; i < depth; i++)
            _moves[iDepth + i] = null;//refactor?
    }

    private int indexOfNull(int start, int depth)//refactor?
    {
        for (int i = start, m = start + depth; i < m; i++)
            if (_moves[i] == null)
                return i;
        return -1;
    }

    public void Grow(int depth) {
        Clear(depth);
        if (depth <= 1)
            return;

        //copy previous line
        int start = Index(depth - 1);
        int nullMove = indexOfNull(start, depth);
        int count = nullMove - start;

        Clear(depth);
        int target = Index(depth);
        for (int i = 0; i < count; i++)
            _moves[target + i] = _moves[start + i];

        //copy to sub-PVs
        for (int i = 1; i < depth; i++) {
            set(i, _moves[target + depth - i]);
        }
    }

    public Move[] GetLine(int depth) {
        int start = Index(depth);
        int nullMove = indexOfNull(start, depth);
        int count = (nullMove == -1) ? depth : nullMove - start;

        Move[] line = new Move[count];
        System.arraycopy(_moves, start, line, 0, count);
        return line;
    }

    public boolean IsGameOver(int depth)
    {
        int start = Index(depth);
        int nullMove = indexOfNull(start, depth);
        return nullMove != -1;
    }

    public Move get(int depth) {
        return _moves[Index(depth)];
    }

    public void set(int depth, Move value) {
        int a = Index(depth);
        _moves[a] = value;

        int b = Index(depth - 1);
        for (int i = 0; i < depth - 1; i++)
            _moves[a + i + 1] = _moves[b + i];
    }

    public static void main(String[] a) {
        PrincipalVariation pv = new PrincipalVariation(5);

        // Dummy moves
        Move m1 = new Move("e2e4");
        Move m2 = new Move("e7e5");
        Move m3 = new Move("g1f3");

        // Set first move
        pv.set(1, m1);

        // Grow to depth 2 and set second move
        pv.Grow(2);
        pv.set(2, m2);

        // Grow to depth 3 and set third move
        pv.Grow(3);
        pv.set(3, m3);

        // Get line
        Move[] line = pv.GetLine(3);
        System.out.println("PV Line (depth 3):");
        for (Move m : line) {
            System.out.println(m);
        }

        // Test get()
        System.out.println("Move at depth 2: " + pv.get(2));

        // Test Clear
        pv.Clear(3);
        System.out.println("After Clear(3):");
        Move[] clearedLine = pv.GetLine(3);
        for (Move m : clearedLine) {
            System.out.println(m);
        }
    }
}