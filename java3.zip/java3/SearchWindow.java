public class SearchWindow {
    public int Floor;//Alpha
    public int Ceiling;//Beta

    public static SearchWindow infinite() {
        return new SearchWindow(Short.MIN_VALUE, Short.MAX_VALUE);
    }

    public SearchWindow(SearchWindow sw) {
        Floor = sw.Floor;
        Ceiling = sw.Ceiling;
    }

    public SearchWindow(int floor, int ceiling) {
        Floor = floor;
        Ceiling = ceiling;
    }

    public boolean Cut(int score, Color color) {
        if (color == Color.White) //Cut floor
        {
            if (score <= Floor)
                return false; //outside search window

            Floor = score;
        } else {
            if (score >= Ceiling) //Cut ceiling
                return false; //outside search window

            Ceiling = score;
        }
        return Floor >= Ceiling; //Cutoff?
    }

    public boolean Inside(int score, Color color) {
        if (color == Color.White)
            return score > Floor;
        else
            return score < Ceiling;
    }

    public boolean Outside(int score, Color color)
    {
        if (color == Color.White)
            return score <= Floor;
        else
            return score >= Ceiling; //outside search window
    }

    public int GetScore(Color color) {
        return color == Color.White ? Floor : Ceiling;
    }

    public SearchWindow GetNullWindow(Color color)
    {
        //used to quickly determine that a move is not improving the score for color.
        if (color == Color.White)
            return new SearchWindow(Floor, Floor + 1);
        else
            return new SearchWindow(Ceiling - 1, Ceiling);
    }
}