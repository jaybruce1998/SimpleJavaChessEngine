import java.util.ArrayList;

public class MoveList extends ArrayList<Move>
{
    static MoveList Quiets(Board position)
    {
        MoveList quietMoves = new MoveList();
        position.CollectQuiets(quietMoves::add);
        return quietMoves;
    }

    static MoveList Captures(Board position)
    {
        MoveList captures = new MoveList();
        position.CollectCaptures(captures::add);
        return captures;
    }

    static MoveList SortedCaptures(Board position)
    {
        MoveList captures = new MoveList();
        position.CollectCaptures(captures::add);
        captures.SortMvvLva(position);
        return captures;
    }

    private static int Score(Board context, Move move)
    {
        Piece victim = context.get(move.ToSquare);
        Piece attacker = context.get(move.FromSquare);
        return Pieces.MaxRank * Pieces.Rank(victim) - Pieces.Rank(attacker);
    }

    public void SortMvvLva(Board context)
    {
        sort((a, b) -> Integer.compare(Score(context, b), Score(context, a)));
    }
}
