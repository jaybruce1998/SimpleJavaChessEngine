import java.util.ArrayList;
import java.util.List;

public class Playmaker
{
	//REFACTOR - don't use Lists?
	public static Iterable<MoveBoard> Play(Board position, int depth, PrincipalVariation pv, KillerMoves killers)
	{
		List<MoveBoard> r=new ArrayList<>();
		//1. PV if available
		Move pvMove = pv.get(depth);
		if (position.CanPlay(pvMove))
		{
			var nextPosition = new Board(position, pvMove);
			if (!nextPosition.IsChecked(position.ActiveColor()))
				r.add(new MoveBoard(pvMove, nextPosition));
				//yield return new MoveBoard(pvMove, nextPosition);
		}

		//2. Captures Mvv-Lva, PV excluded
		MoveList captures = MoveList.Captures(position);
		captures.remove(pvMove);
		captures.SortMvvLva(position);
		for (var capture: captures)
		{
			var nextPosition = new Board(position, capture);
			if (!nextPosition.IsChecked(position.ActiveColor()))
				r.add(new MoveBoard(capture, nextPosition));
				//yield return new MoveBoard(capture, nextPosition);
		}

		//3. Killers if available
		for (Move killer: killers.Get(depth))
			if (killer!=null&&(pvMove==null||!killer.equals(pvMove)) && position.get(killer.ToSquare) == Piece.None && position.CanPlay(killer))//refactor?
			{
				var nextPosition = new Board(position, killer);
				if (!nextPosition.IsChecked(position.ActiveColor()))
					r.add(new MoveBoard(killer, nextPosition));
					//yield return new MoveBoard(killer, nextPosition);
			}

		//4. Play quiet moves that aren't known killers
		for (var move: MoveList.Quiets(position))
			if ((pvMove==null||!move.equals(pvMove)) && !killers.Contains(depth, move))//refactor?
			{
				var nextPosition = new Board(position, move);
				if (!nextPosition.IsChecked(position.ActiveColor()))
					r.add(new MoveBoard(move, nextPosition));
					//yield return new MoveBoard(move, nextPosition);
			}
		return r;
	}

	static Iterable<Board> Play(Board position)
	{
		List<Board> r=new ArrayList<>();
		for (var capture: MoveList.SortedCaptures(position))
		{
			var nextPosition = new Board(position, capture);
			if (!nextPosition.IsChecked(position.ActiveColor()))
				r.add(nextPosition);
				//yield return nextPosition;
		}

		for (var move: MoveList.Quiets(position))
		{
			var nextPosition = new Board(position, move);
			if (!nextPosition.IsChecked(position.ActiveColor()))
				r.add(nextPosition);
				//yield return nextPosition;
		}
		return r;
	}

	static Iterable<Board> PlayCaptures(Board position)
	{
		List<Board> r=new ArrayList<>();
		for (var capture: MoveList.SortedCaptures(position))
		{
			var nextPosition = new Board(position, capture);
			if (!nextPosition.IsChecked(position.ActiveColor()))
				r.add(nextPosition);
				//yield return nextPosition;
		}
		return r;
	}
}