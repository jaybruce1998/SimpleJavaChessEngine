public class PrincipalVariation {
    Move[] _moves=new Move[0];
    int _depth=0;

    private int Index(int depth) {
        //return depth + (depth - 1) + (depth - 2) + ... + 1;
        int d = depth - 1;
        return (d * d + d) / 2;
    }

    private int indexOfNull(int start, int depth)//refactor?
    {
        for (int i = start, m = start + depth; i < m; i++)
            if (_moves[i] == null)
                return i;
        return -1;
    }

    public void Grow(int depth)
    {
        while (_depth < depth)
            Grow();
    }

    private void Grow()
    {
        _depth++;
        int size = Index(_depth + 1);
        Move[] moves = new Move[size];
        //copy pv lines to new array
        int to = 0;
        for (int depth = 0; depth < _depth; depth++)
        {
            //copy the last d elements of the mainline
            for (int i = 0; i < depth; i++)
                moves[to++] = _moves[_moves.length-(depth - i)];
            //leave one free
            to++;
        }
        _moves = moves;
    }

    public Move[] GetLine(int depth) {
        int start = Index(depth);
        int nullMove = indexOfNull(start, depth);
        int count = (nullMove == -1) ? depth : nullMove - start;

        Move[] line = new Move[count];
        System.arraycopy(_moves, start, line, 0, count);
        return line;
    }

    public boolean IsGameOver(int depth)
    {
        int start = Index(depth);
        int nullMove = indexOfNull(start, depth);
        return nullMove != -1;
    }

    public Move get(int depth) {
        return _moves[Index(depth)];
    }

    public void set(int depth, Move value) {
        int a = Index(depth);
        _moves[a] = value;

        int b = Index(depth - 1);
        for (int i = 0; i < depth - 1; i++)
            _moves[a + i + 1] = _moves[b + i];
    }

    public static void main(String[] a) {

    }
}