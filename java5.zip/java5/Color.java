public enum Color {
    Black(-1),
    White(1);

    public final int value;

    Color(int value) {
        this.value = value;
    }
}
