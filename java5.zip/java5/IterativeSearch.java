import java.util.function.Supplier;

public class IterativeSearch {
    private static final int QUERY_TC_FREQUENCY = 25;
    private long NodesVisited;
    public long getNodesVisited()
    {
        return NodesVisited;
    }
    private int Depth;

    private int Score;
    public int getScore() {
        return Score;
    }

    public Move[] PrincipalVariation() {
        return _pv.GetLine(Depth);
    }

    public boolean Aborted() {
        return NodesVisited >= _maxNodes || _killSwitch.Get(NodesVisited % QUERY_TC_FREQUENCY == 0);
    }

    public boolean GameOver() {
        return Evaluation.IsCheckmate(Score);
    }

    private final Board _root;
    private final PrincipalVariation _pv;
    KillerMoves _killers;
    private KillSwitch _killSwitch;
    long _maxNodes;

    public IterativeSearch(Board board, long maxNodes)
    {
        _root = new Board(board);
        _pv = new PrincipalVariation();
        _killers = new KillerMoves(4);
        _maxNodes = maxNodes;
    }

    public IterativeSearch(Board board)
    {
        this(board, Long.MAX_VALUE);
    }

    public void Search(int maxDepth) {
        while (!GameOver()&&maxDepth > Depth)
            searchDeeper();
    }

    public void searchDeeper() {
        SearchDeeper(null);
    }

    public void SearchDeeper(Supplier<Boolean> killSwitch) {
        if (GameOver())
            return;

        _pv.Grow(++Depth);
        _killers.Grow(Depth);
        _killSwitch = new KillSwitch(killSwitch);
        SearchWindow window = SearchWindow.infinite();
        Score = EvalPosition(_root, Depth, window);
    }

    private int EvalPositionTT(Board position, int depth, SearchWindow window, boolean isNullMove)
    {
        int[] score=new int[1];
        if (Transpositions.GetScore(position, depth, window, score))
        {
            _pv.Truncate(depth);
            return score[0];
        }

        score[0] = EvalPosition(position, depth, new SearchWindow(window), isNullMove);
        Transpositions.Store(position.getZobristHash(), depth, window, score[0], null);//refactor?
        return score[0];
    }

    private int EvalPositionTT(Board position, int depth, SearchWindow window)
    {
        return EvalPositionTT(position, depth, window, false);
    }

    private int EvalPosition(Board position, int depth, SearchWindow window, boolean isNullMove)
    {
        if (depth <= 0)
        {
            Evaluation.DynamicScore = Evaluation.ComputeMobility(position);
            return QEval(position, window);
        }

        NodesVisited++;
        if (Aborted())
            return 0;

        Color color = position.getSideToMove();
        //should we try null move pruning?
        if (depth >= 2 && !isNullMove && !position.IsChecked(color))
        {
            final int R = 2;
            //skip making a move
            Board nullChild = Playmaker.PlayNullMove(position);
            //evaluate the position at reduced depth with a null-window around beta
            SearchWindow nullWindow = window.GetUpperBound(color);
            int nullScore = EvalPositionTT(nullChild, depth - R - 1, new SearchWindow(nullWindow), true);
            //is the evaluation "too good" despite null-move? then don't waste time on a branch that is likely going to fail-high
            if (nullWindow.Cut(nullScore, color))
                return nullScore;
        }

        //do a regular expansion...
        int expandedNodes = 0;
        for (MoveBoard mb: Playmaker.Play(position, depth, _pv, _killers))
        {
            Move move=mb.move;
            Board child=mb.board;
            expandedNodes++;

            //moves after the PV node are unlikely to raise alpha.
            if (expandedNodes > 1 && depth >= 3 && window.Width() > 0)
            {
                //we can save a lot of nodes by searching with "null window" first, proving cheaply that the score is below alpha...
                SearchWindow nullWindow = window.GetLowerBound(color);
                int nullScore = EvalPositionTT(child, depth - 1, new SearchWindow(nullWindow));
                if (!nullWindow.Inside(nullScore, color))
                    continue;
            }

            //this node may raise alpha!
            int score = EvalPositionTT(child, depth - 1, new SearchWindow(window));
            if (window.Inside(score, color))
            {
                Transpositions.Store(position.getZobristHash(), depth, window, score, move);
                _pv.set(depth, move);
                //...and maybe get a beta cutoff
                if (window.Cut(score, color))
                {
                    //we remember killers like hat!
                    if (position.get(move.ToSquare) == Piece.None)
                        _killers.Add(move, depth);

                    return window.GetScore(color);
                }
            }
        }

        //no playable moves in this position?
        if (expandedNodes == 0)
        {
            //clear PV because the game is over
            _pv.set(depth, null);//refactor?

            if (position.IsChecked(color))
                return Evaluation.Checkmate(color); //lost!
            else
                return 0; //draw!
        }

        return window.GetScore(color);
    }

    private int EvalPosition(Board position, int depth, SearchWindow window)
    {
        return EvalPosition(position, depth, window, false);
    }

    private int QEval(Board position, SearchWindow window)
    {
        NodesVisited++;
        if (Aborted())
            return 0;
        Color color = position.getSideToMove();

        //if inCheck we can't use standPat, need to escape check!
        boolean inCheck = position.IsChecked(color);
        if (!inCheck)
        {
            int standPatScore = Evaluation.DynamicScore + Evaluation.Evaluate(position);
            //Cut will raise alpha and perform beta cutoff when standPatScore is too good
            if (window.Cut(standPatScore, color))
                return window.GetScore(color);
        }

        int expandedNodes = 0;
        //play remaining captures (or any moves if king is in check)
        for (Board child: inCheck ? Playmaker.Play(position) : Playmaker.PlayCaptures(position))
        {
            expandedNodes++;
            //recursively evaluate the resulting position (after the capture) with QEval
            int score = QEval(child, new SearchWindow(window));

            //Cut will raise alpha and perform beta cutoff when the move is too good
            if (window.Cut(score, color))
                break;
        }

        //checkmate?
        if (expandedNodes == 0 && inCheck)
            return Evaluation.Checkmate(color);

        //stalemate?
        if (expandedNodes == 0 && !LegalMoves.HasMoves(position))
            return 0;

        //can't capture. We return the 'alpha' which may have been raised by "stand pat"
        return window.GetScore(color);
    }
}