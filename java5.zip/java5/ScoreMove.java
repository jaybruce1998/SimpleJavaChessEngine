public class ScoreMove
{
	public int score;
	public Move move;
	public ScoreMove(int score, Move move)
	{
		this.score = score;
		this.move = move;
	}
}