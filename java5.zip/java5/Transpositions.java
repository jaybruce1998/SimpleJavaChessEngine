public class Transpositions
{
	public enum ScoreType
	{
		GreaterOrEqual,
		LessOrEqual,
		Exact
	}

	public static class HashEntry
	{
		public long Hash;       //8 Bytes
		public short Score;      //2 Bytes
		public short Depth;      //2 Bytes
		public ScoreType Type;   //1 Byte
		public Move BestMove;    //3 Bytes
		//==================================
		//                        16 Bytes
	}

	public static short PERSISTENT = 9999;
	public static final int DEFAULT_SIZE_MB = 50;
	private static final int ENTRY_SIZE = 16; //BYTES
	static HashEntry[] _table;

	static int Index(long hash)
	{
		return (int)(hash % _table.length);
	}

	static
	{
		Resize(DEFAULT_SIZE_MB);
	}

	public static void Resize(int hashSizeMBytes)
	{
		int length = (hashSizeMBytes * 1024 * 1024) / ENTRY_SIZE;
		_table = new HashEntry[length];
		Clear();//refactor?
	}

	public static void Clear()
	{
		for(int i=0; i<_table.length; i++)
			_table[i]=new HashEntry();
	}

	public static void Store(long zobristHash, int depth, SearchWindow window, int score, Move bestMove)
	{
		int index = Index(zobristHash);
		HashEntry entry = _table[index];
		if (entry.Depth == PERSISTENT)
			return;

		//don't overwrite a "best move" unless it's a new position OR the new bestMove is explored to a greater depth
		if (entry.Hash != zobristHash || (depth >= entry.Depth && bestMove!=null))
			_table[index].BestMove = bestMove;

		entry.Hash = zobristHash;
		entry.Depth = (short)Math.max(0, depth);

		if (score >= window.Ceiling)
		{
			entry.Type = ScoreType.GreaterOrEqual;
			entry.Score = (short)window.Ceiling;
		}
		else if(score <= window.Floor)
		{
			entry.Type = ScoreType.LessOrEqual;
			entry.Score = (short)window.Floor;
		}
		else
		{
			entry.Type = ScoreType.Exact;
			entry.Score = (short)score;
		}
	}

	static Move GetBestMove(Board position)
	{
		long zobristHash = position.getZobristHash();
		int index = Index(zobristHash);
		if (_table[index].Hash == zobristHash)
			return _table[index].BestMove;
		else
			return null;
	}

	public static boolean GetScore(Board position, int depth, SearchWindow window, int[] score)
	{
		long zobristHash = position.getZobristHash();
		int index = Index(zobristHash);
		HashEntry entry = _table[index];

		score[0] = entry.Score;
		if (entry.Hash != zobristHash || entry.Depth < depth)
			return false;

		//1.) score is exact and within window
		if (entry.Type == ScoreType.Exact)
			return true;
		//2.) score is below floor
		if (entry.Type == ScoreType.LessOrEqual && score[0] <= window.Floor)
			return true; //failLow
		//3.) score is above ceiling
        return entry.Type == ScoreType.GreaterOrEqual && score[0] >= window.Ceiling; //failHigh
    }
}